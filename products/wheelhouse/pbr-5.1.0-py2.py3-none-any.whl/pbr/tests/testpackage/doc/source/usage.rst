========
Usage
========

To use testpackage in a project::

    import testpackage
